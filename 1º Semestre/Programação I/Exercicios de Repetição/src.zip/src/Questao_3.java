public class Questao_3 {
    public static void main(String []args){
        int num;
        int N = 100;
        for(num = 0; num < 100; num++){
            N = N - 1;
            System.out.println(N + " ");
            

        }
    }

}
