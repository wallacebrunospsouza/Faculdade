public class Questao_1 {
    public static void main(String[] args){
        int num;
        for(num = 1; num <= 100; num++){
            System.out.println(num + " ");

        }
    }

}
