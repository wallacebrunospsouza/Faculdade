public class Questao_2 {
    public static void main(String[] args) {
        int num;
        double N = 0;
        for (num = 0; num < 25; num++) {
            N = N + 2;
            System.out.println(N + " ");

        }

    }
}